Ejercicio:
Hacer un Header con uimagen, un fixed nav y un Footer.

